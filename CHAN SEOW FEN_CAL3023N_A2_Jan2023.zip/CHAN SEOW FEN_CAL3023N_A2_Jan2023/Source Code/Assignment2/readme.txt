Please make sure every java file package is
package Assignment2;